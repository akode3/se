import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  HostListener,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
} from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { timer, Subscription, BehaviorSubject } from 'rxjs';
import { SessionInterruptService } from './services/session-interrupt.service';
import { SessionTimerService } from './services/session-timer.service';

@Component({
  selector: 'session-expiration-alert',
  templateUrl: './session-expiration-alert.component.html',
  styleUrls: ['./session-expiration-alert.component.css', './btn.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SessionExpirationAlertComponent
  implements OnInit, OnChanges, OnDestroy
{
  /**
   * Should start the timer or not. Usually, you can set it to true if a user is authenticated.
   */
  @Input() startTimer? = true;

  /**
   * Count down seconds.
   */
  @Input() alertAt? = 60;

  showModal = false;
  expired = false;
  private sessionTimerSubscription!: Subscription;

  countDown: Subscription | undefined;
  counter = 600;
  tick = 1000;

  constructor(
    private el: ElementRef,
    private sessionInterrupter: SessionInterruptService,
    public sessionTimer: SessionTimerService,
    private modalService: NgbModal) {
    }

  ngOnInit() {
    if (!this.sessionTimerSubscription && this.startTimer) {
      this.trackSessionTime();
    }
    // move element to bottom of page (just before </body>)
    // so it can be displayed above everything else
    document.body.appendChild(this.el.nativeElement);
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['startTimer']) {
      this.cleanUp();
      if (changes['startTimer'].currentValue) {
        this.trackSessionTime();
      }
    }
  }

  private trackSessionTime() {
    this.sessionTimer.startTimer();
    this.expired = false;
    this.sessionTimerSubscription = this.sessionTimer.remainSeconds$.subscribe(
      (t) => {
        if (t === this.alertAt) {
          this.open();
        }
        if (t === 0) {
          this.expired = true;
          this.cleanUp();
          this.sessionInterrupter.onExpire();
        }
      }
    );
  }
  continue() {
    this.sessionInterrupter.continueSession();
    this.sessionTimer.resetTimer();
    this.countDown = undefined;
    this.close();
  }
  logout() {
    this.sessionTimer.stopTimer();
    this.close();
    this.sessionInterrupter.stopSession();
    this.countDown = undefined;
  }

  open(): void {
    this.showModal = true;
    document.body.classList.add('sea-modal-open');
    console.log("Open Modal Window");
    this.countDown = this.getCounter(this.tick)
      .subscribe(() => this.counter--);
  }

  close(): void {
    this.showModal = false;
    document.body.classList.remove('sea-modal-open');
  }

  cleanUp() {
    this.sessionTimer.stopTimer();
    if (this.sessionTimerSubscription) {
      this.sessionTimerSubscription.unsubscribe();
    }
  }
  reload() {
    this.close();
    location.reload();
  }

  ngOnDestroy(): void {
    this.el.nativeElement.remove();
    this.cleanUp();
    this.countDown = undefined;
  }

  @HostListener('document:keydown.tab', ['$event'])
  handleTabKey(e: KeyboardEvent) {
    const modal = document.querySelector('#session-expiration-alert');
    if (modal) {
      const btn1 = modal.querySelector<HTMLButtonElement>('button.btn-primary');
      const btn2 = modal.querySelector<HTMLButtonElement>('button.btn-secondary');
      if (document.activeElement === btn1) {
        btn2?.focus();
        e.preventDefault();
      }
    }
  }
  @HostListener('document:keydown.shift.tab', ['$event'])
  handleShiftTabKey(e: KeyboardEvent) {
    const modal = document.querySelector('#session-expiration-alert');
    if (modal) {
      const btn1 = modal.querySelector<HTMLButtonElement>('button.btn-primary');
      const btn2 = modal.querySelector<HTMLButtonElement>('button.btn-secondary');
      if (document.activeElement === btn2) {
        btn1?.focus();
        e.preventDefault();
      }
    }
  }

  getCounter(tick: any) {
    return timer(0, tick);
  }

  transform(observable: BehaviorSubject<number>): string {
    //MM:SS format
    let value = observable.getValue();
    const minutes: number = Math.floor(value / 60);
    return (
    ("00" + minutes).slice(-2) +
    ":" +
    ("00" + Math.floor(value - minutes * 60)).slice(-2)
    );

    // for HH:MM:SS
    //const hours: number = Math.floor(value / 3600);
    //const minutes: number = Math.floor((value % 3600) / 60);
    //return ('00' + hours).slice(-2) + ':' + ('00' + minutes).slice(-2) + ':' + ('00' + Math.floor(value - minutes * 60)).slice(-2);
}
}
