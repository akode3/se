import { Component, OnInit } from '@angular/core';
import { SessionTimerService } from './session-expiration-alert/services/session-timer.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit{
  alertAt = 15;
  startTimer = true;

  constructor(public sessionTimer: SessionTimerService) {
    console.log("constructor");
  }
  ngOnInit(): void {
    console.log("ngOnInit");
  }
  increase() {
    this.alertAt++;
  }
  toggleTimer() {
    this.startTimer = !this.startTimer;
  }
}
